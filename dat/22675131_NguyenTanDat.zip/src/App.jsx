import TinhToan from "./components/TinhToan";
function App() {
    return (
        <div className="">
            <h1 className="">
                <TinhToan />
            </h1>
        </div>
    );
}

export default App;
