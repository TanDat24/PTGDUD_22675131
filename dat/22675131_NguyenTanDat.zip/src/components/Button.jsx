// eslint-disable-next-line react/prop-types
const Button = ({ onClick }) => {
    return (
        <div>
            <button className="" onClick={onClick}>
                Tính toán
            </button>
        </div>
    );
};
export default Button;
